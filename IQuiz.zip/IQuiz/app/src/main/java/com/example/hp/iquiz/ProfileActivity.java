package com.example.hp.iquiz;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class ProfileActivity extends AppCompatActivity implements View.OnClickListener {
    //firebase auth object
    private FirebaseAuth firebaseAuth;

    //view objects
    private Button start_quiz;
    private Button leaderboard;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        //initializing firebase authentication object
        firebaseAuth = FirebaseAuth.getInstance();
        //if the user is not logged in
        //that means current user will return null
        if (firebaseAuth.getCurrentUser() == null) {
            //closing this activity
            finish();
            //starting login activity
            startActivity(new Intent(this, LoginActivity.class));
        }

        //getting current user
        //FirebaseUser user = firebaseAuth.getCurrentUser();

        //initializing views
        start_quiz = (Button) findViewById(R.id.start_quiz);
        leaderboard = (Button) findViewById(R.id.leaderboard);
        //displaying logged in user name
        //adding listener to button
        start_quiz.setOnClickListener(this);
        leaderboard.setOnClickListener(this);
    }


    @Override
    public void onClick(View view) {
       // Toast.makeText(this, "Please enter password", Toast.LENGTH_LONG).show();
        if(view == start_quiz )
        {

            startActivity(new Intent(this,StartQuizActivity.class));
        }
        if(view == leaderboard)
        {
            startActivity(new Intent(this,LeaderboardActivity.class));
        }
        }

    }

