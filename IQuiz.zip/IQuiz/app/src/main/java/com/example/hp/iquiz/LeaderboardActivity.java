package com.example.hp.iquiz;

import android.support.v7.app.AppCompatActivity;



public class LeaderboardActivity extends AppCompatActivity {

}
