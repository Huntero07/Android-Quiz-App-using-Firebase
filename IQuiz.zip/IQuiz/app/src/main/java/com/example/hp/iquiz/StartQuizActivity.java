package com.example.hp.iquiz;

        import android.content.Intent;
        import android.os.Bundle;
        import android.support.v7.app.AppCompatActivity;
        import android.view.View;
        import android.widget.Button;
        import android.widget.RadioButton;
        import android.widget.RadioGroup;
        import android.widget.TextView;
        import android.widget.Toast;
        import com.google.firebase.auth.FirebaseAuth;
        import com.google.firebase.database.DataSnapshot;
        import com.google.firebase.database.DatabaseError;
        import com.google.firebase.database.DatabaseReference;
        import com.google.firebase.database.FirebaseDatabase;
        import com.google.firebase.database.ValueEventListener;


public class StartQuizActivity extends AppCompatActivity {
    private FirebaseAuth firebaseAuth;
    //view objects
    private TextView Question;
    private RadioButton option1;
    private RadioButton option2;
    private RadioButton option3;
    private RadioButton option4;
    private Button next;
    private RadioGroup radio;
    int questionid = 1;
    private int Score = 0;
    int totalQ = 0;
    String answer;
    private TextView score;
   // private String current_user=firebaseAuth.getCurrentUser().toString();

    DatabaseReference mRootRef = FirebaseDatabase.getInstance().getReference();
    DatabaseReference mconditionref = mRootRef.child("questions");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.quizactivity);
        firebaseAuth = FirebaseAuth.getInstance();
        if (firebaseAuth.getCurrentUser() == null) {
            //closing this activity

            finish();
            //starting login activity
            startActivity(new Intent(this, LoginActivity.class));
        }
        Question = (TextView) findViewById(R.id.Question);
        option1 = (RadioButton) findViewById(R.id.option1);
        option2 = (RadioButton) findViewById(R.id.option2);
        option3 = (RadioButton) findViewById(R.id.option3);
        option4 = (RadioButton) findViewById(R.id.option4);
        next = (Button) findViewById(R.id.nextQuiz);
        radio = (RadioGroup) findViewById(R.id.radio);

        mconditionref.addValueEventListener(new ValueEventListener() {
                                                @Override
                                                public void onDataChange(DataSnapshot dataSnapshot) {

                                                    Question.setText(dataSnapshot.child("1").child("question").getValue().toString());
                                                    option1.setText(dataSnapshot.child("1").child("option1").getValue().toString());
                                                    option2.setText(dataSnapshot.child("1").child("option2").getValue().toString());
                                                    option3.setText(dataSnapshot.child("1").child("option3").getValue().toString());
                                                    option4.setText(dataSnapshot.child("1").child("option4").getValue().toString());
                                                     answer = dataSnapshot.child("1").child("answer").getValue().toString();
                                                    totalQ=(int)dataSnapshot.getChildrenCount();

                                                    // Toast.makeText(StartQuizActivity.this,totalQ+" "+questionid,Toast.LENGTH_SHORT).show();
                                                }
                                                @Override
                                                public void onCancelled(DatabaseError databaseError) {
                                                }
                                            }
        );

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (option1.isChecked())
                {
                    if(answer.equals("option 1"))
                        Score++;
                }
                if (option2.isChecked())
                {
                    if(answer.equals("option 2"))
                        Score++;
                }
                if (option3.isChecked())
                {
                    if(answer.equals("option 3"))
                        Score++;


                }
                if (option4.isChecked()){
                    if(answer.equals("option 4"))
                        Score++;
                }
                radio.clearCheck();
                if(questionid >= totalQ){
                   // Toast.makeText(StartQuizActivity.this, "Your Test is Over Score: "+Score, Toast.LENGTH_LONG).show();
                    //next.setVisibility(View.GONE);
                    setContentView(R.layout.activity_finish);
                    score = (TextView) findViewById(R.id.score);
                    score.setText(/*current_user+*/" Your score is "+Score+".");
                }
                else {
                    // Toast.makeText(StartQuizActivity.this,Score+"",Toast.LENGTH_SHORT).show();

                    questionid++;
                    getq();
                }
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
    }


    public void getq()
    {
        mconditionref.child(""+questionid).addValueEventListener(new ValueEventListener() {
                                                @Override
                                                public void onDataChange(DataSnapshot dataSnapshot) {

                                                    Question.setText(dataSnapshot.child("question").getValue().toString());
                                                    option1.setText(dataSnapshot.child("option1").getValue().toString());
                                                    option2.setText(dataSnapshot.child("option2").getValue().toString());
                                                    option3.setText(dataSnapshot.child("option3").getValue().toString());
                                                    option4.setText(dataSnapshot.child("option4").getValue().toString());
                                                     answer = dataSnapshot.child("answer").getValue().toString();

                                                }

                                                @Override
                                                public void onCancelled(DatabaseError databaseError) {

                                                }
                                            }
        );
    }
}
